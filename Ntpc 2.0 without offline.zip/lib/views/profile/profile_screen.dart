import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:ntpcsecond/controllers/allinprovider.dart';
import 'package:provider/provider.dart';

import '../../theme/common_them.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    AllInProvider provider = Provider.of(context, listen: false);
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(CommonAppTheme.backgroundImage),
            fit: BoxFit.cover,
          ),
        ),
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                children: [
                  const SizedBox(
                    height: 50,
                  ),
                  ListTile(
                    onTap: () {
                      provider.viewProfile(context, provider.empCode);
                    },
                    leading: const CircleAvatar(
                      radius: 30.0,
                      backgroundImage: AssetImage("assets/images/profile.png"),
                    ),
                    title: Text(
                      "Saurabh Banaudha",
                      style: CommonAppTheme.textstyleWithColorBlack,
                    ),
                    subtitle: const Text(
                      "(Emp. No. 008692,)",
                      style: TextStyle(color: Colors.black),
                    ),
                  ),
                  const SizedBox(
                    height: 50,
                  ),
                  ListTile(
                    onTap: () {
                      provider.viewProfile(context, provider.empCode);
                    },
                    leading: const Icon(
                      Icons.person,
                      color: Colors.black,
                    ),
                    title: Text(
                      "Profile",
                      style: CommonAppTheme.textstyleWithColorBlack,
                    ),
                  ),
                  ListTile(
                    leading: const Icon(
                      Icons.person,
                      color: Colors.black,
                    ),
                    title: Text(
                      "Admin",
                      style: CommonAppTheme.textstyleWithColorBlack,
                    ),
                  ),
                  ListTile(
                    onTap: () {
                      provider.getManasReportData(
                          context, provider.requiredDataForFilter);
                    },
                    leading: const Icon(
                      Icons.report,
                      color: Colors.black,
                    ),
                    title: Text(
                      "Manas Report",
                      style: CommonAppTheme.textstyleWithColorBlack,
                    ),
                  ),
                  ListTile(
                    leading: const Icon(
                      Icons.person,
                      color: Colors.black,
                    ),
                    title: Text(
                      "Masters",
                      style: CommonAppTheme.textstyleWithColorBlack,
                    ),
                  ),
                  ListTile(
                    leading: const Icon(
                      Icons.person,
                      color: Colors.black,
                    ),
                    title: Text(
                      "Modules",
                      style: CommonAppTheme.textstyleWithColorBlack,
                    ),
                  ),
                  ListTile(
                    onTap: () {
                      Navigator.pushNamed(context, '/change_password');
                    },
                    leading: const Icon(
                      Icons.person,
                      color: Colors.black,
                    ),
                    title: Text(
                      "Change Password",
                      style: CommonAppTheme.textstyleWithColorBlack,
                    ),
                  ),
                ],
              ),
              ListTile(
                onTap: () async {
                  final _storage = const FlutterSecureStorage();
                  Navigator.pop(context);
                  await _storage.delete(key: 'ntpctwo_isuser_login');
                  Navigator.of(context).pushNamedAndRemoveUntil(
                      '/is_user_login_screen', (Route<dynamic> route) => false);
                },
                leading: const Icon(
                  Icons.login,
                  color: Colors.black,
                ),
                title: Text(
                  "Log Out",
                  style: CommonAppTheme.textstyleWithColorBlack,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
