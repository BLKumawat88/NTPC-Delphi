import 'package:flutter/material.dart';
import 'package:ntpcsecond/controllers/allinprovider.dart';
import 'package:ntpcsecond/views/profile/profile_screen.dart';
import 'package:provider/provider.dart';

import '../../theme/common_them.dart';

class HomeScreen extends StatelessWidget {
  HomeScreen({super.key});

  final List gridData = [
    {"title": "Key position Monitoring", "image": "assets/images/g1.png"},
    {"title": "SPV Analysis", "image": "assets/images/g2.png"},
    {"title": "E-Market Place", "image": "assets/images/g3.png"},
    {"title": "Open Search", "image": "assets/images/g4.png"},
    {"title": "Succession Planning", "image": "assets/images/g5.png"},
    {"title": "Job Rotation", "image": "assets/images/g6.png"},
  ];

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;

    AllInProvider provider = Provider.of(context, listen: false);

    /*24 is for notification bar on Android*/
    final double itemHeight = (size.height - kToolbarHeight - 24) / 4;
    final double itemWidth = size.width / 2;
    return Scaffold(
      extendBodyBehindAppBar: true,
      drawer: const ProfileScreen(),
      appBar: AppBar(
        title: Text(
          "Manpower Planning System",
          style: CommonAppTheme.textstyleWithColorBlackF18,
        ),
        elevation: 0,
        backgroundColor: Colors.transparent,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(CommonAppTheme.backgroundImage),
            fit: BoxFit.cover,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.only(top: 50),
            child: GridView.count(
              primary: false,
              padding: const EdgeInsets.all(20),
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              crossAxisCount: 2,
              childAspectRatio: (itemWidth / itemHeight),
              children: <Widget>[
                ...gridData
                    .map(
                      (e) => InkWell(
                        onTap: () {
                          if (gridData.indexOf(e) == 0) {
                            provider.deptGroupFilterValues.clear();
                            provider.deptsubGroupFilterValues.clear();
                            provider.deptFilterValues.clear();
                            provider.projectCategoryFilterValues.clear();
                            provider.locationFilterValues.clear();
                            provider.gradeFilterValues.clear();
                            provider.levelFilterValues.clear();
                            provider.getKeyPositionMonitoringData(
                                context,
                                provider.keyPositionSearch_Post_filter_value,
                                false,
                                true,
                                "Main/KeyPostions_Search_Post",
                                true);
                          } else if (gridData.indexOf(e) == 1) {
                            Map<String, String> spvAnalysisRegionFilterData = {
                              'Department': '',
                              'Region': '',
                              'ProjectCategory': '',
                              'Project': '',
                              'Grade': '',
                              'Spv_Dept_Type': '0',
                              'Spv_Dept_Group': '0',
                              'SortBy': '',
                              'UserID': '${provider.empCode}',
                              'UserRole': provider.userRole,
                              'ProjectType': '${provider.empProjectType}',
                              'RegionID': '${provider.empRegionID}',
                            };

                            provider.setSpvAnalysisRequiredFilters(
                                context, 1, spvAnalysisRegionFilterData, true);
                          } else if (gridData.indexOf(e) == 2) {
                            provider.isBack = true;
                            // Navigator.pushNamed(context, '/comparing_profile');
                            Navigator.pushNamed(context, '/e_market_place');
                          } else if (gridData.indexOf(e) == 3) {
                            provider.searchUserByNameId = "";
                            provider.totalRecord = 0;
                            provider.clearOpenSearchListData();
                            provider.setRequiredFilterForOpenSearch(
                              context,
                              true,
                            );
                            // provider.getOpenSearchEmpData(context,
                            //     provider.openSearchRequiedFieldsToGetData);
                          } else if (gridData.indexOf(e) == 4) {
                            provider.deptGroupFilterValues.clear();
                            provider.deptsubGroupFilterValues.clear();
                            provider.deptFilterValues.clear();
                            provider.projectCategoryFilterValues.clear();
                            provider.locationFilterValues.clear();
                            provider.gradeFilterValues.clear();
                            provider.levelFilterValues.clear();

                            provider.getKeyPositionMonitoringData(
                                context,
                                provider.keyPositionSearch_Post_filter_value,
                                false,
                                true,
                                "Main/Succession_Search_Post",
                                false);
                          } else if (gridData.indexOf(e) == 5) {
                            provider.getJobRotationDataList(context,
                                provider.jobRotation_value, false, true);
                          }
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                                colors: [
                                  const Color(0xFF0C6DAE),
                                  const Color(0xFF239DEE),
                                ],
                                begin: const FractionalOffset(0.0, 0.0),
                                end: const FractionalOffset(0.0, 1.0),
                                stops: [0.0, 1.0],
                                tileMode: TileMode.clamp),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Image.asset(
                                e['image'],
                                width: 42,
                              ),
                              SizedBox(
                                  height: CommonAppTheme.lineheightSpace20),
                              Text(
                                e['title'],
                                style: const TextStyle(
                                  color: Colors.white,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
                      ),
                    )
                    .toList()
              ],
            ),
          ),
        ),
      ),
    );
  }
}
