import 'package:flutter/material.dart';
import 'package:multi_select_flutter/multi_select_flutter.dart';
import 'package:provider/provider.dart';

import '../../controllers/allinprovider.dart';
import '../../theme/common_them.dart';

class SPVAnalysisRegionScreen extends StatelessWidget {
  const SPVAnalysisRegionScreen({super.key});
  Widget returnTableColumnLable(title) {
    return Padding(
      padding: const EdgeInsets.all(4.0),
      child: Text(
        title,
        style: const TextStyle(color: Colors.white),
      ),
    );
  }

  Widget returnRowData(title) {
    return Text(
      title,
      style: const TextStyle(
        color: Colors.black,
        fontSize: 12,
      ),
    );
  }

  void showAvailableFilter(context) {
    AllInProvider provider = Provider.of(context, listen: false);
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        enableDrag: true,
        isDismissible: true,
        isScrollControlled: true,
        builder: (context) {
          return StatefulBuilder(
            builder: (context, setState) => Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom,
              ),
              child: Container(
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(
                      30,
                    ),
                    topRight: Radius.circular(
                      30,
                    ),
                  ),
                ),
                // height: MediaQuery.of(context).size.height / 1,
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(
                          height: 10,
                        ),
                        Center(
                          child: Container(
                            width: 60,
                            height: 5,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(50),
                              color: const Color(0xFFD9D9D9),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 16,
                        ),
                        Center(
                          child: Text(
                            "Select Filters",
                            style: TextStyle(
                              color: Color(CommonAppTheme.buttonCommonColor),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: CommonAppTheme.lineheightSpace20,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: MultiSelectDialogField(
                                dialogHeight: 250,
                                searchable: true,
                                initialValue: provider.masterRegionValues,
                                items: provider.masterRegionFilterData,
                                title: const Text(
                                  "Region",
                                  style: TextStyle(color: Colors.black),
                                ),
                                selectedColor: Colors.black,
                                decoration: const BoxDecoration(
                                  color: Color(0xFFF0F6FA),
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(10)),
                                ),
                                buttonIcon: Icon(Icons.arrow_drop_down,
                                    color: Color(
                                        CommonAppTheme.buttonCommonColor)),
                                buttonText: Text(
                                  "Region",
                                  style: TextStyle(
                                    color:
                                        Color(CommonAppTheme.buttonCommonColor),
                                    fontSize: 16,
                                  ),
                                ),
                                onConfirm: (results) {
                                  setState(
                                    () {
                                      provider.masterRegionValues.clear();
                                      provider.masterRegionValues
                                          .addAll(results);
                                    },
                                  );

                                  if (results.isEmpty) {
                                    //to show all filter values again

                                    setState(() {
                                      if (provider
                                          .masterProjectValues.isNotEmpty) {
                                        provider.masterProjectValues.clear();
                                        Navigator.pop(context);
                                        showAvailableFilter(context);
                                      }

                                      provider.masterProjectDummyData.clear();
                                      provider.masterProjectDummyData =
                                          provider.projectF.map((subjectdataa) {
                                        return MultiSelectItem(subjectdataa,
                                            subjectdataa['pCategory']);
                                      }).toList();
                                    });
                                  } else {
                                    setState(() {
                                      provider.masterProjectDummyData.clear();
                                    });
                                    List dataAfterFilter = [];
                                    for (var i = 0; i < results.length; i++) {
                                      print(results[i]['regionCode']
                                          .toInt()
                                          .runtimeType);
                                      dataAfterFilter.addAll(
                                          provider.projectF.where((element) {
                                        return element['regionID'] ==
                                            results[i]['regionCode']
                                                .toInt()
                                                .toString();
                                      }).toList());
                                    }
                                    print("fsdf ${dataAfterFilter.length} ");
                                    provider.masterProjectDummyData =
                                        dataAfterFilter.map((subjectdataa) {
                                      return MultiSelectItem(subjectdataa,
                                          subjectdataa['pCategory']);
                                    }).toList();
                                  }
                                },
                              ),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            Expanded(
                              child: MultiSelectDialogField(
                                dialogHeight: 250,
                                searchable: true,
                                initialValue: provider.masterProjectValues,
                                items: provider.masterProjectDummyData,
                                title: const Text(
                                  "Location",
                                  style: TextStyle(color: Colors.black),
                                ),
                                selectedColor: Colors.black,
                                decoration: const BoxDecoration(
                                  color: Color(0xFFF0F6FA),
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(10)),
                                ),
                                buttonIcon: Icon(Icons.arrow_drop_down,
                                    color: Color(
                                        CommonAppTheme.buttonCommonColor)),
                                buttonText: Text(
                                  "Location",
                                  style: TextStyle(
                                    color:
                                        Color(CommonAppTheme.buttonCommonColor),
                                    fontSize: 16,
                                  ),
                                ),
                                onConfirm: (results) {
                                  setState(() {
                                    provider.masterProjectValues.clear();
                                    provider.masterProjectValues
                                        .addAll(results);
                                  });
                                },
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: CommonAppTheme.lineheightSpace20,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Container(
                                child: Column(
                                  children: [
                                    Consumer<AllInProvider>(
                                      builder: (context, value, child) =>
                                          MultiSelectDialogField(
                                        dialogHeight: 250,
                                        searchable: true,
                                        initialValue: provider
                                            .projectCategoryFilterValues,
                                        items: provider.projectCategoryDummy,
                                        title: const Text(
                                          "Proj. Category",
                                          style: TextStyle(color: Colors.black),
                                        ),
                                        selectedColor: Colors.black,
                                        decoration: const BoxDecoration(
                                          color: Color(0xFFF0F6FA),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(10)),
                                          // border: Border.all(
                                          //   color: Colors.black,
                                          //   width: 1,
                                          // ),
                                        ),
                                        buttonIcon: Icon(Icons.arrow_drop_down,
                                            color: Color(CommonAppTheme
                                                .buttonCommonColor)),
                                        buttonText: Text(
                                          "Proj. Category",
                                          style: TextStyle(
                                            color: Color(CommonAppTheme
                                                .buttonCommonColor),
                                            fontSize: 16,
                                          ),
                                        ),
                                        onConfirm: (results) {
                                          // To show selected Filter
                                          setState(
                                            () {
                                              provider
                                                  .projectCategoryFilterValues
                                                  .clear();
                                              provider
                                                  .projectCategoryFilterValues
                                                  .addAll(results);
                                            },
                                          );
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Expanded(
                              child: Container(
                                child: Column(
                                  children: [
                                    MultiSelectDialogField(
                                      dialogHeight: 250,
                                      searchable: true,
                                      initialValue: provider.gradeFilterValues,
                                      items: provider.grade,
                                      title: const Text(
                                        "Grade",
                                        style: TextStyle(color: Colors.black),
                                      ),
                                      selectedColor: Colors.black,
                                      decoration: const BoxDecoration(
                                        color: Color(0xFFF0F6FA),
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(10)),
                                        // border: Border.all(
                                        //   color: Colors.black,
                                        //   width: 1,
                                        // ),
                                      ),
                                      buttonIcon: Icon(Icons.arrow_drop_down,
                                          color: Color(CommonAppTheme
                                              .buttonCommonColor)),
                                      buttonText: Text(
                                        "Grade",
                                        style: TextStyle(
                                          color: Color(
                                              CommonAppTheme.buttonCommonColor),
                                          fontSize: 16,
                                        ),
                                      ),
                                      onConfirm: (results) {
                                        //to show all filter values again
                                        setState(() {
                                          provider.gradeFilterValues.clear();
                                          provider.gradeFilterValues
                                              .addAll(results);
                                        });
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: CommonAppTheme.lineheightSpace20,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: MultiSelectDialogField(
                                dialogHeight: 250,
                                searchable: true,
                                initialValue: provider.spvDeptTypeValues,
                                items: provider.spvDeptType,
                                title: const Text(
                                  "SPV Dept. Type",
                                  style: TextStyle(color: Colors.black),
                                ),
                                selectedColor: Colors.black,
                                decoration: const BoxDecoration(
                                  color: Color(0xFFF0F6FA),
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(10)),
                                ),
                                buttonIcon: Icon(Icons.arrow_drop_down,
                                    color: Color(
                                        CommonAppTheme.buttonCommonColor)),
                                buttonText: Text(
                                  "SPV Dept. Type",
                                  style: TextStyle(
                                    color:
                                        Color(CommonAppTheme.buttonCommonColor),
                                    fontSize: 16,
                                  ),
                                ),
                                onConfirm: (results) {
                                  provider.spvDeptTypeValues.clear();
                                  provider.spvDeptTypeValues.addAll(results);

                                  //to show all filter values again
                                  if (results.isEmpty) {
                                    setState(() {
                                      if (provider
                                          .deptFilterValues.isNotEmpty) {
                                        provider.deptFilterValues.clear();
                                        Navigator.pop(context);
                                        showAvailableFilter(context);
                                      }
                                      provider.masterDepartmentFilterDummyData
                                          .clear();
                                      provider.masterDepartmentFilterDummyData =
                                          provider.departmentsF
                                              .map((subjectdataa) {
                                        return MultiSelectItem(subjectdataa,
                                            subjectdataa['deptName']);
                                      }).toList();
                                    });
                                  } else {
                                    setState(() {
                                      provider.masterDepartmentFilterDummyData
                                          .clear();
                                    });

                                    List dataAfterFilter = [];
                                    for (var i = 0; i < results.length; i++) {
                                      print("${results[i]}");
                                      dataAfterFilter.addAll(provider
                                          .departmentsF
                                          .where((element) {
                                        return element['groupDeptCode'] ==
                                            results[i]['dept_Group'].toInt();
                                      }).toList());
                                    }

                                    provider.masterDepartmentFilterDummyData =
                                        dataAfterFilter.map((subjectdataa) {
                                      return MultiSelectItem(subjectdataa,
                                          subjectdataa['deptName']);
                                    }).toList();
                                  }
                                },
                              ),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            Expanded(
                              child: Container(
                                child: Column(
                                  children: [
                                    MultiSelectDialogField(
                                      dialogHeight: 250,
                                      searchable: true,
                                      initialValue:
                                          provider.masterDepartmentFilterValues,
                                      items: provider
                                          .masterDepartmentFilterDummyData,
                                      title: const Text(
                                        "SPV Dept.",
                                        style: TextStyle(color: Colors.black),
                                      ),
                                      selectedColor: Colors.black,
                                      decoration: const BoxDecoration(
                                        color: Color(0xFFF0F6FA),
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(10)),
                                        // border: Border.all(
                                        //   color: Colors.black,
                                        //   width: 1,
                                        // ),
                                      ),
                                      buttonIcon: Icon(Icons.arrow_drop_down,
                                          color: Color(CommonAppTheme
                                              .buttonCommonColor)),
                                      buttonText: Text(
                                        "SPV Dept.",
                                        style: TextStyle(
                                          color: Color(
                                              CommonAppTheme.buttonCommonColor),
                                          fontSize: 16,
                                        ),
                                      ),
                                      onConfirm: (results) {
                                        setState(() {
                                          provider.masterDepartmentFilterValues
                                              .clear();
                                          provider.masterDepartmentFilterValues
                                              .addAll(results);
                                        });
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: CommonAppTheme.lineheightSpace20,
                        ),
                        Row(
                          children: [
                            Expanded(
                              child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.red,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(20.0),
                                    ),
                                  ),
                                  onPressed: () {
                                    Map<String, String>
                                        spvAnalysisRegionFilterData = {
                                      'Department': '',
                                      'Region': '',
                                      'ProjectCategory': '',
                                      'Project': '',
                                      'Grade': '',
                                      'Spv_Dept_Type': '0',
                                      'Spv_Dept_Group': '0',
                                      'SortBy': '',
                                      'UserID': '${provider.empCode}',
                                      'UserRole': provider.userRole,
                                      'ProjectType':
                                          '${provider.empProjectType}',
                                      'RegionID': '${provider.empRegionID}',
                                    };
                                    provider.masterRegionValues.clear();
                                    provider.masterProjectValues.clear();
                                    provider.projectCategoryFilterValues
                                        .clear();
                                    provider.gradeFilterValues.clear();
                                    provider.spvDeptTypeValues.clear();
                                    provider.deptFilterValues.clear();

                                    provider.setSpvAnalysisRequiredFilters(
                                        context,
                                        1,
                                        spvAnalysisRegionFilterData,
                                        false);
                                  },
                                  child: const Text("Clear All")),
                            ),
                            const SizedBox(
                              width: 50,
                            ),
                            Expanded(
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Color(
                                    CommonAppTheme.buttonCommonColor,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20.0),
                                  ),
                                ),
                                onPressed: () {
                                  applyFilter(context);
                                },
                                child: const Text("Search"),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: CommonAppTheme.lineheightSpace20,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
        });
  }

  applyFilter(context) {
    AllInProvider provider = Provider.of(context, listen: false);

    provider.masterRegionIds.clear();
    provider.masterProjectIds.clear();
    provider.projectCategoryFilterIds.clear();
    provider.gradeFilterIds.clear();
    provider.spvDeptTypeIds.clear();
    provider.deptFilterIds.clear();

    for (int i = 0; i < provider.masterRegionValues.length; i++) {
      provider.masterRegionIds.add(
        provider.masterRegionValues[i]['regionCode'].toInt(),
      );
    }

    for (int i = 0; i < provider.masterProjectValues.length; i++) {
      provider.masterProjectIds.add(provider.masterProjectValues[i]['pid']);
    }

    for (int i = 0; i < provider.projectCategoryFilterValues.length; i++) {
      provider.projectCategoryFilterIds
          .add(provider.projectCategoryFilterValues[i]['projectTypeID']);
    }

    for (int i = 0; i < provider.gradeFilterValues.length; i++) {
      provider.gradeFilterIds.add(provider.gradeFilterValues[i]['levelCode']);
    }

    for (int i = 0; i < provider.spvDeptTypeValues.length; i++) {
      provider.spvDeptTypeIds.add(provider.spvDeptTypeValues[i]['dept_Group']);
    }

    for (int i = 0; i < provider.masterDepartmentFilterValues.length; i++) {
      provider.deptFilterIds
          .add(provider.masterDepartmentFilterValues[i]['deptCode']);
    }

    Map<String, String> spvAnalysisRegionFilterData = {
      'Department': provider.deptFilterIds.join(','),
      'Region': provider.masterRegionIds.join(','),
      'ProjectCategory': provider.projectCategoryFilterIds.join(','),
      'Project': provider.masterProjectIds.join(','),
      'Grade': provider.gradeFilterIds.join(','),
      'Spv_Dept_Type': '0',
      'Spv_Dept_Group': '0',
      'SortBy': '',
      'UserID': '${provider.empCode}',
      'UserRole': provider.userRole,
      'ProjectType': '${provider.empProjectType}',
      'RegionID': '${provider.empRegionID}',
    };

    provider.setSpvAnalysisRequiredFilters(
        context, 1, spvAnalysisRegionFilterData, false);

    print("spvAnalysis filter data $spvAnalysisRegionFilterData");
  }

  @override
  Widget build(BuildContext context) {
    AllInProvider provider = Provider.of(context, listen: false);
    bool isExpandedValue = false;
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.transparent,
        title: Text(
          "SPV Analysis",
          style: TextStyle(color: Colors.black),
        ),
        leading: InkWell(
          onTap: () {
            Navigator.pop(context);
          },
          child: const Icon(Icons.arrow_back_ios),
        ),
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(CommonAppTheme.backgroundImage),
            fit: BoxFit.cover,
          ),
        ),
        child: Padding(
          padding: EdgeInsets.all(CommonAppTheme.screenPadding),
          child: SafeArea(
            child: ListView(
              children: [
                Consumer<AllInProvider>(
                  builder: (context, value, child) => Card(
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(CommonAppTheme.borderRadious),
                    ),
                    clipBehavior: Clip.antiAlias,
                    margin: EdgeInsets.zero,
                    child: ExpansionTile(
                      onExpansionChanged: ((value) {
                        // setState(() {
                        //   isExpandedValue = value;
                        // });
                      }),
                      trailing: Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Color(CommonAppTheme.whiteColor),
                        ),
                        child: Icon(
                          isExpandedValue
                              ? Icons.arrow_drop_up
                              : Icons.arrow_drop_down,
                          size: 30,
                          color: Color(CommonAppTheme.appthemeColorForText),
                        ),
                      ),
                      backgroundColor: Color(CommonAppTheme.headerCommonColor),
                      collapsedBackgroundColor:
                          Color(CommonAppTheme.headerCommonColor),
                      title: Text(
                        "Summary",
                        style: TextStyle(
                          color: Color(
                            CommonAppTheme.whiteColor,
                          ),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 1),
                          child: Container(
                            decoration: const BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.only(
                                  bottomLeft: Radius.circular(7),
                                  bottomRight: Radius.circular(7),
                                )),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 5, vertical: 5),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          Text(
                                            "S- ",
                                            style: TextStyle(
                                              color: Color(
                                                CommonAppTheme
                                                    .appthemeColorForText,
                                              ),
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                          Text(
                                            provider.keyPositionMonitoringSummaryData[
                                                's'],
                                            style: const TextStyle(
                                                fontWeight: FontWeight.bold),
                                          )
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          Text("P- ",
                                              style: TextStyle(
                                                color: Color(
                                                  CommonAppTheme
                                                      .appthemeColorForText,
                                                ),
                                                fontWeight: FontWeight.bold,
                                              )),
                                          Text(
                                            provider.keyPositionMonitoringSummaryData[
                                                'p'],
                                            style: const TextStyle(
                                                fontWeight: FontWeight.bold),
                                          )
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          Text("V- ",
                                              style: TextStyle(
                                                color: Color(
                                                  CommonAppTheme
                                                      .appthemeColorForText,
                                                ),
                                                fontWeight: FontWeight.bold,
                                              )),
                                          Text(
                                            "${int.parse(provider.keyPositionMonitoringSummaryData['s']) - int.parse(provider.keyPositionMonitoringSummaryData['p'])}",
                                            style: const TextStyle(
                                                fontWeight: FontWeight.bold),
                                          )
                                        ],
                                      ),
                                    ],
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Text(
                                    "To Be Vacant Key Positions",
                                    style: TextStyle(
                                      color: Color(
                                        CommonAppTheme.appthemeColorForText,
                                      ),
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      InkWell(
                                        onTap: () {
                                          provider
                                              .getSummySectonOneMTwoMSixMData(
                                                  context,
                                                  {"VacantDays": "30"});
                                        },
                                        child: Text(
                                          "1 Mon. - ${provider.keyPositionMonitoringSummaryData['1mon']}",
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Color(CommonAppTheme
                                                .headerCommonColor),
                                            decoration:
                                                TextDecoration.underline,
                                            // decorationColor: Color(
                                            //   CommonAppTheme.buttonCommonColor,
                                            // ),
                                          ),
                                        ),
                                      ),
                                      InkWell(
                                        onTap: () {
                                          provider
                                              .getSummySectonOneMTwoMSixMData(
                                                  context,
                                                  {"VacantDays": "90"});
                                        },
                                        child: Text(
                                          "3 Mon. - ${provider.keyPositionMonitoringSummaryData['3mon']}",
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Color(CommonAppTheme
                                                .headerCommonColor),
                                            decoration:
                                                TextDecoration.underline,
                                          ),
                                        ),
                                      ),
                                      InkWell(
                                        onTap: () {
                                          provider
                                              .getSummySectonOneMTwoMSixMData(
                                                  context,
                                                  {"VacantDays": "180"});
                                        },
                                        child: Text(
                                          "6 Mon. - ${provider.keyPositionMonitoringSummaryData['6mon']}",
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Color(CommonAppTheme
                                                .headerCommonColor),
                                            decoration:
                                                TextDecoration.underline,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: CommonAppTheme.lineheightSpace20,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    InkWell(
                      onTap: () {
                        // downloadExcelFile(
                        //   ExcelDownloadType.M,
                        //   provider,
                        // );
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: Color(
                            CommonAppTheme.buttonCommonColor,
                          ),
                          borderRadius: BorderRadius.circular(
                              CommonAppTheme.borderRadious),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Row(
                            children: [
                              Icon(
                                Icons.file_download_outlined,
                                color: Color(
                                  CommonAppTheme.whiteColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    InkWell(
                      onTap: () {
                        showAvailableFilter(context);
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: Color(
                            CommonAppTheme.buttonCommonColor,
                          ),
                          borderRadius: BorderRadius.circular(
                            CommonAppTheme.borderRadious,
                          ),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Row(
                            children: [
                              Icon(
                                Icons.filter_list_outlined,
                                color: Color(
                                  CommonAppTheme.whiteColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      child: Align(
                        alignment: Alignment.topRight,
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(
                                CommonAppTheme.borderRadious),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 5),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  height: 30,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(
                                      20,
                                    ),
                                    color: Color(CommonAppTheme.whiteColor),
                                  ),
                                  width: 120,
                                  child: Padding(
                                    padding: const EdgeInsets.only(left: 0),
                                    child: TextFormField(
                                      onChanged: (value) {
                                        provider.monitoringSearch(value);
                                      },

                                      decoration: InputDecoration(
                                        border: InputBorder.none,
                                        hintText: "Search",
                                        hintStyle:
                                            const TextStyle(color: Colors.grey),
                                        filled: true,
                                        fillColor: Colors.white,
                                        contentPadding:
                                            const EdgeInsets.fromLTRB(
                                                10, 0, 0, 0),
                                        enabledBorder: OutlineInputBorder(
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(20.0)),
                                          borderSide: BorderSide(
                                            color: Color(
                                                CommonAppTheme.whiteColor),
                                          ),
                                        ),
                                        focusedBorder: OutlineInputBorder(
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(20.0)),
                                          borderSide: BorderSide(
                                            color: Color(
                                                CommonAppTheme.whiteColor),
                                          ),
                                        ),
                                        suffixIcon: Padding(
                                          padding: const EdgeInsets.all(2.0),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              color: Color(
                                                CommonAppTheme
                                                    .buttonCommonColor,
                                              ),
                                            ),
                                            child: InkWell(
                                              onTap: () {
                                                // provider
                                                //     .monitoringSearch(
                                                //         minitoringSearch
                                                //             .text);
                                                // print(minitoringSearch
                                                //     .text);
                                              },
                                              child: Icon(
                                                Icons.search,
                                                color: Color(
                                                    CommonAppTheme.whiteColor),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      // readOnly: true,ddhd
                                      onTap: () {
                                        //Go to the next screen
                                      },
                                      cursorColor: Colors.grey,
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: CommonAppTheme.lineheightSpace20,
                ),
                Consumer<AllInProvider>(builder: (context, person, _) {
                  return Container(
                    width: MediaQuery.of(context).size.width,
                    decoration:
                        BoxDecoration(borderRadius: BorderRadius.circular(0)),
                    child: DataTable(
                      horizontalMargin: 0,
                      columnSpacing: 2,
                      border: TableBorder.all(
                          color: Colors.grey,
                          borderRadius: BorderRadius.circular(0)),
                      dataRowHeight: 40,
                      headingRowColor: MaterialStateProperty.all(
                        Color(CommonAppTheme.buttonCommonColor),
                      ),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(0),
                      ),
                      columns: <DataColumn>[
                        DataColumn(
                          label: returnTableColumnLable('Region'),
                        ),
                        DataColumn(
                          label: returnTableColumnLable('Prop. Req'),
                        ),
                        DataColumn(
                          label: returnTableColumnLable('Imp'),
                        ),
                        DataColumn(
                          label: returnTableColumnLable('Surplus'),
                        ),
                      ],
                      rows: <DataRow>[
                        ...provider.spvAnalysisRegionDataMain.map(
                          (e) {
                            return DataRow(
                              color: MaterialStateProperty.resolveWith<Color?>(
                                  (Set<MaterialState> states) {
                                if (states.contains(MaterialState.selected)) {
                                  return Theme.of(context)
                                      .colorScheme
                                      .primary
                                      .withOpacity(0.08);
                                }
                                return Colors.white; // Use the default value.
                              }),
                              cells: <DataCell>[
                                DataCell(
                                  InkWell(
                                    onTap: () {
                                      provider.spvRegionId = e['region_Code'];
                                      if (e['regionName'] != "Grand Total") {
                                        Map<String, String>
                                            spvAnalysisProjectFilterData = {
                                          'SearchRegionID':
                                              provider.spvRegionId.toString(),
                                          'Department': '',
                                          'Region': '',
                                          'ProjectCategory': '',
                                          'Project': '',
                                          'Grade': '',
                                          'Spv_Dept_Type': '0',
                                          'Spv_Dept_Group': '0',
                                          'SortBy': '',
                                          'UserID': '${provider.empCode}',
                                          'UserRole': provider.userRole,
                                          'ProjectType':
                                              '${provider.empProjectType}',
                                          'RegionID': '${provider.empRegionID}',
                                        };

                                        provider.selectedRegionName =
                                            e['regionName'];
                                        provider.setSpvAnalysisRequiredFilters(
                                            context,
                                            2,
                                            spvAnalysisProjectFilterData,
                                            true);
                                      } else {
                                        print("Clicked on Grand total");
                                      }
                                    },
                                    child: Text(
                                      ' ${e['regionName']}',
                                      style: TextStyle(
                                        color: Color(
                                          CommonAppTheme.buttonCommonColor,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                DataCell(
                                  Center(
                                    child: returnRowData(
                                      ' ${e['total']}',
                                    ),
                                  ),
                                ),
                                DataCell(
                                  Center(
                                    child: returnRowData(
                                      ' ${e['p_Total']}',
                                    ),
                                  ),
                                ),
                                DataCell(
                                  InkWell(
                                    onTap: () {
                                      // if (e['totalPositioned'] > 0) {
                                      //   provider.getKeyPostionPositionedEmpData(
                                      //       context, {
                                      //     "PositionID": "${e['positionID']}"
                                      //   });
                                      // }
                                    },
                                    child: Center(
                                      child: Text(
                                        '${e['t_Total']}',
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            );
                          },
                        ).toList()
                      ],
                    ),
                  );
                }),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
