import 'package:ntpcsecond/controllers/allinprovider.dart';
import 'package:provider/provider.dart';
import '../../theme/common_dialog.dart';
import '../../theme/common_them.dart';
import '../commonheader/common_header.dart';
import 'package:flutter/material.dart';

class OpenSearchScreen extends StatefulWidget {
  const OpenSearchScreen({super.key});
  @override
  State<OpenSearchScreen> createState() => _OpenSearchScreenState();
}

class _OpenSearchScreenState extends State<OpenSearchScreen> {
  late ScrollController _controller;

  @override
  void initState() {
    AllInProvider provider = Provider.of(context, listen: false);
    // TODO: implement initState
    super.initState();
    _controller = ScrollController()
      ..addListener(
        () => {
          if (_controller.position.maxScrollExtent ==
              _controller.position.pixels)
            {provider.loadMoreData(context, false)}
        },
      );
  }

  TextEditingController searchUserDataByNameId = TextEditingController();
  bool isExpandedValue = false;
  List compareList = [];
  Widget employeeDetail(title, value) {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              flex: 2,
              child: Text(
                "$title",
                style: TextStyle(
                  color: Color(
                    CommonAppTheme.appthemeColorForText,
                  ),
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Expanded(
              flex: 5,
              child: Text(
                " $value",
                style: const TextStyle(),
              ),
            ),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
      ],
    );
  }

  // List of items in our dropdown menu
  var items = [
    {'title': 'Sort By', 'value': ""},
    {"title": 'Emp No. Asc', "value": "Order By EmpNo"},
    {"title": 'Emp No. Desc', "value": "Order By EmpNo Desc"},
    {"title": 'Name Asc', "value": "Order By FirstName"},
    {'title': 'Name Desc', "value": "Order By FirstName DESC"}
  ];

  Widget displaySelectedFilter(
      filterTitle, selectedFilterName, applyFilterCat, providerAccess) {
    return Container(
      margin: const EdgeInsets.only(right: 10),
      decoration: BoxDecoration(
          color: Color(CommonAppTheme.buttonCommonColor),
          borderRadius: BorderRadius.circular(CommonAppTheme.borderRadious)),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          children: [
            Text(
              filterTitle,
              style: const TextStyle(color: Colors.white),
            ),
            ...applyFilterCat
                .map(
                  (e) => Text(
                    "${e['$selectedFilterName']} , ",
                    style: TextStyle(
                      color: Color(
                        CommonAppTheme.whiteColor,
                      ),
                    ),
                  ),
                )
                .toList(),
            InkWell(
              onTap: () {
                applyFilterCat.clear();
                providerAccess.clearOpenSearchListData();
                providerAccess.applyMasterFilter(context, false);
              },
              child: const Text(
                " X ",
                style: TextStyle(
                  color: Colors.red,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    AllInProvider provider = Provider.of(context, listen: false);

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: OpenSearchHeader.commonAppBarHeader(
        "Open Search",
        context,
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(CommonAppTheme.backgroundImage),
            fit: BoxFit.cover,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: EdgeInsets.all(CommonAppTheme.screenPadding),
            child: SingleChildScrollView(
              controller: _controller,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 50,
                    decoration: BoxDecoration(
                        borderRadius:
                            BorderRadius.circular(CommonAppTheme.borderRadious),
                        color: Color(CommonAppTheme.buttonCommonColor)),
                    child: Center(
                      child: Consumer<AllInProvider>(
                        builder: (context, value, child) => Text(
                          "Employees List(Total - ${provider.totalRecord} employees found out of ${provider.totalEmpCount})",
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Expanded(
                          child: Container(
                        height: 35,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(
                            20,
                          ),
                          color: Color(CommonAppTheme.whiteColor),
                        ),
                        width: 120,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 0),
                          child: TextFormField(
                            controller: searchUserDataByNameId,
                            onChanged: (value) {
                              provider.searchUserByNameId = value;
                            },
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: "Search",
                              hintStyle: const TextStyle(color: Colors.grey),
                              filled: true,
                              fillColor: Colors.white,
                              contentPadding:
                                  const EdgeInsets.fromLTRB(10, 0, 0, 0),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: const BorderRadius.all(
                                    Radius.circular(20.0)),
                                borderSide: BorderSide(
                                  color: Color(CommonAppTheme.whiteColor),
                                ),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: const BorderRadius.all(
                                    Radius.circular(20.0)),
                                borderSide: BorderSide(
                                  color: Color(CommonAppTheme.whiteColor),
                                ),
                              ),
                              suffixIcon: Padding(
                                padding: const EdgeInsets.all(2.0),
                                child: InkWell(
                                  onTap: () {
                                    provider.clearOpenSearchListData();
                                    // searchUserDataByNameId.text = "";
                                    provider.applyMasterFilter(context, false);
                                    // provider.clearFilterValues(
                                    //   context,
                                    //   false,
                                    // );
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Color(
                                          CommonAppTheme.buttonCommonColor,
                                        )),
                                    child: Icon(
                                      Icons.search,
                                      color: Color(CommonAppTheme.whiteColor),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            // readOnly: true,ddhd
                            onTap: () {
                              //Go to the next screen
                            },
                            cursorColor: Colors.grey,
                          ),
                        ),
                      )),
                      const SizedBox(
                        width: 50,
                      ),
                      DropdownButton(
                        // Initial Value
                        value: provider.sortByValue,

                        // Down Arrow Icon
                        icon: const Icon(Icons.keyboard_arrow_down),

                        // Array list of items
                        items: items.map(
                          (items) {
                            return DropdownMenuItem(
                              value: items['value'],
                              child: Text("${items['title']}"),
                            );
                          },
                        ).toList(),
                        // After selecting the desired option,it will
                        // change button value to selected value
                        onChanged: (String? newValue) {
                          setState(() {
                            provider.sortByValue = newValue!;
                          });
                          provider.clearOpenSearchListData();
                          provider.applyMasterFilter(context, false);
                        },
                      ),
                    ],
                  ),
                  SizedBox(
                    height: CommonAppTheme.lineheightSpace20,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          color: Color(
                            CommonAppTheme.appCommonGreenColor,
                          ),
                          borderRadius: BorderRadius.circular(
                              CommonAppTheme.borderRadious),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Row(
                            children: [
                              Image.asset(
                                "assets/images/compare.png",
                                width: 25,
                                color: Color(CommonAppTheme.whiteColor),
                              ),
                              Text(
                                "Export Emp.",
                                style: TextStyle(
                                  color: Color(
                                    CommonAppTheme.whiteColor,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: CommonAppTheme.lineheightSpace20,
                  ),
                  Consumer<AllInProvider>(
                    builder: (context, value, child) => provider
                                .masterDepartmentGroupFilterValues.isNotEmpty ||
                            provider.masterDepartmentSubGroupFilterValues
                                .isNotEmpty ||
                            provider.masterDepartmentFilterValues.isNotEmpty ||
                            provider.masterWorkProfileValues.isNotEmpty ||
                            provider.masterDepartmentExpEmpGroupValue != "" ||
                            provider.masterRegionValues.isNotEmpty ||
                            provider.masterProjectValues.isNotEmpty ||
                            provider.masterCategoryValues.isNotEmpty ||
                            provider.masterProjectCategoryValues.isNotEmpty ||
                            provider
                                .masterCurrentProjectRegionValues.isNotEmpty ||
                            provider
                                .masterCurrentProjectProjectValues.isNotEmpty ||
                            provider.masterCurrentProjectProjectLocationValues
                                .isNotEmpty ||
                            provider.masterDepartmentDepartmentGroupFilterValues
                                .isNotEmpty ||
                            provider
                                .masterDepartmentDepartmentSubGroupFilterValues
                                .isNotEmpty ||
                            provider.masterDepartmentDepartmentFilterValues
                                .isNotEmpty ||
                            provider
                                .masterDepartmentWorkProfileValues.isNotEmpty ||
                            provider.masterStatesValues.isNotEmpty ||
                            provider.masterEmployeeGroupValues.isNotEmpty ||
                            provider.masterGradeValues.isNotEmpty ||
                            provider.masterSubstantiveGradeValues.isNotEmpty ||
                            provider.masterLavelValues.isNotEmpty ||
                            provider.masterGenderSelectedValue != "" ||
                            provider.masterPHHearing ||
                            provider.masterPHOrtho ||
                            provider.masterPHVisual ||
                            provider.masterVigilanceSelectedValue == "1" ||
                            provider.masterVigilanceSelectedValue == "2" ||
                            provider.masterAssociationsCommitteesValues
                                .isNotEmpty ||
                            provider
                                .masterAssociationsMemberValues.isNotEmpty ||
                            provider
                                .masterAssociationsFacultyValues.isNotEmpty ||
                            provider
                                .masterInterestAwardInterestValues.isNotEmpty ||
                            provider.masterInterestAwardAchievementValues
                                .isNotEmpty ||
                            provider.isAgeSelected ||
                            provider.isGeneralBalanceSelected
                        ? Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SingleChildScrollView(
                                scrollDirection: Axis.horizontal,
                                child: Card(
                                  margin: EdgeInsets.zero,
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 12, horizontal: 10),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        InkWell(
                                          onTap: () {
                                            provider.clearOpenSearchListData();
                                            provider.clearFilterValues(
                                                context, false);
                                          },
                                          child: const Text(
                                            "Clear All  ",
                                            style: TextStyle(
                                                color: Colors.red,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                        provider.masterVigilanceSelectedValue ==
                                                    "1" ||
                                                provider.masterVigilanceSelectedValue ==
                                                    "2"
                                            ? Container(
                                                margin: const EdgeInsets.only(
                                                    right: 10),
                                                decoration: BoxDecoration(
                                                    color: Color(CommonAppTheme
                                                        .buttonCommonColor),
                                                    borderRadius: BorderRadius
                                                        .circular(CommonAppTheme
                                                            .borderRadious)),
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(8.0),
                                                  child: Row(
                                                    children: [
                                                      Text(
                                                        "Vigilance : ${provider.masterVigilanceSelectedValue == "1" ? "Included" : "Excluded"}",
                                                        style: TextStyle(
                                                          color: Colors.white,
                                                        ),
                                                      ),
                                                      InkWell(
                                                        onTap: () {
                                                          setState(() {
                                                            provider.masterVigilanceSelectedValue =
                                                                "0";
                                                          });

                                                          provider
                                                              .clearOpenSearchListData();
                                                          provider
                                                              .applyMasterFilter(
                                                            context,
                                                            false,
                                                          );
                                                        },
                                                        child: const Text(
                                                          "  X ",
                                                          style: TextStyle(
                                                            color: Colors.red,
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              )
                                            : SizedBox(),
                                        provider.isGeneralBalanceSelected
                                            ? Container(
                                                margin: const EdgeInsets.only(
                                                    right: 10),
                                                decoration: BoxDecoration(
                                                    color: Color(CommonAppTheme
                                                        .buttonCommonColor),
                                                    borderRadius: BorderRadius
                                                        .circular(CommonAppTheme
                                                            .borderRadious)),
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(8.0),
                                                  child: Row(
                                                    children: [
                                                      Text(
                                                        "Balance Service : ${provider.generalBalanceMin.round()} - ${provider.generalBalanceMax.round()} Years",
                                                        style: TextStyle(
                                                          color: Colors.white,
                                                        ),
                                                      ),
                                                      InkWell(
                                                        onTap: () {
                                                          setState(
                                                            () {
                                                              provider.isGeneralBalanceSelected =
                                                                  false;
                                                            },
                                                          );
                                                          provider
                                                              .generalBalanceMin = 0;
                                                          provider.generalBalanceMax =
                                                              45;
                                                          provider.generalBalanceServiceMinMax =
                                                              const RangeValues(
                                                                  0, 45);
                                                          provider
                                                              .clearOpenSearchListData();
                                                          provider
                                                              .applyMasterFilter(
                                                            context,
                                                            false,
                                                          );
                                                        },
                                                        child: const Text(
                                                          "  X ",
                                                          style: TextStyle(
                                                            color: Colors.red,
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              )
                                            : SizedBox(),
                                        provider.isAgeSelected
                                            ? Container(
                                                margin: const EdgeInsets.only(
                                                    right: 10),
                                                decoration: BoxDecoration(
                                                    color: Color(CommonAppTheme
                                                        .buttonCommonColor),
                                                    borderRadius: BorderRadius
                                                        .circular(CommonAppTheme
                                                            .borderRadious)),
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(8.0),
                                                  child: Row(
                                                    children: [
                                                      Text(
                                                        "Age : ${provider.generalAgeMin.round()} - ${provider.generalAgeMax.round()} Years",
                                                        style: TextStyle(
                                                          color: Colors.white,
                                                        ),
                                                      ),
                                                      InkWell(
                                                        onTap: () {
                                                          setState(
                                                            () {
                                                              provider.isAgeSelected =
                                                                  false;
                                                            },
                                                          );
                                                          provider.generalAgeMin =
                                                              18;
                                                          provider.generalAgeMax =
                                                              60;
                                                          provider.generalAgeMinMax =
                                                              const RangeValues(
                                                                  18, 60);
                                                          provider
                                                              .clearOpenSearchListData();
                                                          provider
                                                              .applyMasterFilter(
                                                            context,
                                                            false,
                                                          );
                                                        },
                                                        child: const Text(
                                                          "  X ",
                                                          style: TextStyle(
                                                            color: Colors.red,
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              )
                                            : SizedBox(),
                                        provider.masterDepartmentGroupFilterValues
                                                .isNotEmpty
                                            ? Column(
                                                children: [
                                                  Container(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            right: 10),
                                                    decoration: BoxDecoration(
                                                        color: Color(CommonAppTheme
                                                            .buttonCommonColor),
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                CommonAppTheme
                                                                    .borderRadious)),
                                                    child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(8.0),
                                                        child: Row(
                                                          children: [
                                                            const Text(
                                                              "Dept. Group : ",
                                                              style: TextStyle(
                                                                  color: Colors
                                                                      .white),
                                                            ),
                                                            ...provider
                                                                .masterDepartmentGroupFilterValues
                                                                .map(
                                                                  (e) => Text(
                                                                    "${e['groupDeptName']} , ",
                                                                    style:
                                                                        TextStyle(
                                                                      color:
                                                                          Color(
                                                                        CommonAppTheme
                                                                            .whiteColor,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                )
                                                                .toList(),
                                                            InkWell(
                                                              onTap: () {
                                                                provider
                                                                    .masterDepartmentGroupFilterValues
                                                                    .clear();
                                                                provider
                                                                    .clearOpenSearchListData();
                                                                provider
                                                                    .applyMasterFilter(
                                                                        context,
                                                                        false);
                                                              },
                                                              child: const Text(
                                                                " X ",
                                                                style:
                                                                    TextStyle(
                                                                  color: Color
                                                                      .fromARGB(
                                                                          255,
                                                                          250,
                                                                          170,
                                                                          164),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        )),
                                                  ),
                                                ],
                                              )
                                            : const SizedBox(),
                                        provider.masterDepartmentSubGroupFilterValues
                                                .isNotEmpty
                                            ? Container(
                                                margin: const EdgeInsets.only(
                                                    right: 10),
                                                decoration: BoxDecoration(
                                                    color: Color(CommonAppTheme
                                                        .buttonCommonColor),
                                                    borderRadius: BorderRadius
                                                        .circular(CommonAppTheme
                                                            .borderRadious)),
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(8.0),
                                                  child: Row(
                                                    children: [
                                                      const Text(
                                                        "Sub. Group:  ",
                                                        style: TextStyle(
                                                            color:
                                                                Colors.white),
                                                      ),
                                                      ...provider
                                                          .masterDepartmentSubGroupFilterValues
                                                          .map(
                                                            (e) => Text(
                                                              "${e['subDeptName']} , ",
                                                              style: TextStyle(
                                                                color: Color(
                                                                  CommonAppTheme
                                                                      .whiteColor,
                                                                ),
                                                              ),
                                                            ),
                                                          )
                                                          .toList(),
                                                      InkWell(
                                                        onTap: () {
                                                          provider
                                                              .masterDepartmentSubGroupFilterValues
                                                              .clear();
                                                          provider
                                                              .clearOpenSearchListData();
                                                          provider
                                                              .applyMasterFilter(
                                                                  context,
                                                                  false);
                                                        },
                                                        child: const Text(
                                                          " X ",
                                                          style: TextStyle(
                                                            color: Colors.red,
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              )
                                            : const SizedBox(),
                                        provider.masterDepartmentFilterValues
                                                .isNotEmpty
                                            ? Container(
                                                margin: const EdgeInsets.only(
                                                    right: 10),
                                                decoration: BoxDecoration(
                                                    color: Color(CommonAppTheme
                                                        .buttonCommonColor),
                                                    borderRadius: BorderRadius
                                                        .circular(CommonAppTheme
                                                            .borderRadious)),
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(8.0),
                                                  child: Row(
                                                    children: [
                                                      const Text(
                                                        "Dept:  ",
                                                        style: TextStyle(
                                                            color:
                                                                Colors.white),
                                                      ),
                                                      ...provider
                                                          .masterDepartmentFilterValues
                                                          .map(
                                                            (e) => Text(
                                                              "${e['deptName']} , ",
                                                              style: TextStyle(
                                                                color: Color(
                                                                  CommonAppTheme
                                                                      .whiteColor,
                                                                ),
                                                              ),
                                                            ),
                                                          )
                                                          .toList(),
                                                      InkWell(
                                                        onTap: () {
                                                          provider
                                                              .masterDepartmentFilterValues
                                                              .clear();
                                                          provider
                                                              .clearOpenSearchListData();
                                                          provider
                                                              .applyMasterFilter(
                                                                  context,
                                                                  false);
                                                        },
                                                        child: const Text(
                                                          " X ",
                                                          style: TextStyle(
                                                            color: Colors.red,
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              )
                                            : const SizedBox(),
                                        provider.masterWorkProfileValues
                                                .isNotEmpty
                                            ? Container(
                                                margin: const EdgeInsets.only(
                                                    right: 10),
                                                decoration: BoxDecoration(
                                                    color: Color(CommonAppTheme
                                                        .buttonCommonColor),
                                                    borderRadius: BorderRadius
                                                        .circular(CommonAppTheme
                                                            .borderRadious)),
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(8.0),
                                                  child: Row(
                                                    children: [
                                                      const Text(
                                                        "Work Profile:  ",
                                                        style: TextStyle(
                                                            color:
                                                                Colors.white),
                                                      ),
                                                      ...provider
                                                          .masterWorkProfileValues
                                                          .map(
                                                            (e) => Text(
                                                              "${e['workProfile']} , ",
                                                              style: TextStyle(
                                                                color: Color(
                                                                  CommonAppTheme
                                                                      .whiteColor,
                                                                ),
                                                              ),
                                                            ),
                                                          )
                                                          .toList(),
                                                      InkWell(
                                                        onTap: () {
                                                          provider
                                                              .masterWorkProfileValues
                                                              .clear();
                                                          provider
                                                              .clearOpenSearchListData();
                                                          provider
                                                              .applyMasterFilter(
                                                                  context,
                                                                  false);
                                                        },
                                                        child: const Text(
                                                          " X ",
                                                          style: TextStyle(
                                                            color: Colors.red,
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              )
                                            : const SizedBox(),
                                        provider.masterDepartmentExpEmpGroupValue !=
                                                ""
                                            ? Container(
                                                margin: const EdgeInsets.only(
                                                    right: 10),
                                                decoration: BoxDecoration(
                                                    color: Color(CommonAppTheme
                                                        .buttonCommonColor),
                                                    borderRadius: BorderRadius
                                                        .circular(CommonAppTheme
                                                            .borderRadious)),
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(8.0),
                                                  child: Row(
                                                    children: [
                                                      const Text(
                                                        "Emp. Group Exp :  ",
                                                        style: TextStyle(
                                                            color:
                                                                Colors.white),
                                                      ),
                                                      Text(
                                                        provider
                                                            .masterDepartmentExpEmpGroupValue,
                                                        style: TextStyle(
                                                          color: Color(
                                                            CommonAppTheme
                                                                .whiteColor,
                                                          ),
                                                        ),
                                                      ),
                                                      InkWell(
                                                        onTap: () {
                                                          provider.masterDepartmentExpEmpGroupValue =
                                                              "";
                                                          provider
                                                              .clearOpenSearchListData();
                                                          provider
                                                              .applyMasterFilter(
                                                                  context,
                                                                  false);
                                                        },
                                                        child: const Text(
                                                          " X ",
                                                          style: TextStyle(
                                                            color: Colors.red,
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              )
                                            : const SizedBox(),
                                        provider.masterRegionValues.isNotEmpty
                                            ? Container(
                                                margin: const EdgeInsets.only(
                                                    right: 10),
                                                decoration: BoxDecoration(
                                                    color: Color(CommonAppTheme
                                                        .buttonCommonColor),
                                                    borderRadius: BorderRadius
                                                        .circular(CommonAppTheme
                                                            .borderRadious)),
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(8.0),
                                                  child: Row(
                                                    children: [
                                                      const Text(
                                                        "Region Loc. Exp.:  ",
                                                        style: TextStyle(
                                                            color:
                                                                Colors.white),
                                                      ),
                                                      ...provider
                                                          .masterRegionValues
                                                          .map(
                                                            (e) => Text(
                                                              "${e['regionName']} , ",
                                                              style: TextStyle(
                                                                color: Color(
                                                                  CommonAppTheme
                                                                      .whiteColor,
                                                                ),
                                                              ),
                                                            ),
                                                          )
                                                          .toList(),
                                                      InkWell(
                                                        onTap: () {
                                                          provider
                                                              .masterRegionValues
                                                              .clear();
                                                          provider
                                                              .clearOpenSearchListData();
                                                          provider
                                                              .applyMasterFilter(
                                                                  context,
                                                                  false);
                                                        },
                                                        child: const Text(
                                                          " X ",
                                                          style: TextStyle(
                                                            color: Colors.red,
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              )
                                            : const SizedBox(),
                                        provider.masterProjectValues.isNotEmpty
                                            ? Container(
                                                margin: const EdgeInsets.only(
                                                    right: 10),
                                                decoration: BoxDecoration(
                                                    color: Color(CommonAppTheme
                                                        .buttonCommonColor),
                                                    borderRadius: BorderRadius
                                                        .circular(CommonAppTheme
                                                            .borderRadious)),
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(8.0),
                                                  child: Row(
                                                    children: [
                                                      const Text(
                                                        "Project Loc. Exp.:  ",
                                                        style: TextStyle(
                                                            color:
                                                                Colors.white),
                                                      ),
                                                      ...provider
                                                          .masterProjectValues
                                                          .map(
                                                            (e) => Text(
                                                              "${e['pCategory']} , ",
                                                              style: TextStyle(
                                                                color: Color(
                                                                  CommonAppTheme
                                                                      .whiteColor,
                                                                ),
                                                              ),
                                                            ),
                                                          )
                                                          .toList(),
                                                      InkWell(
                                                        onTap: () {
                                                          provider
                                                              .masterProjectValues
                                                              .clear();
                                                          provider
                                                              .clearOpenSearchListData();
                                                          provider
                                                              .applyMasterFilter(
                                                                  context,
                                                                  false);
                                                        },
                                                        child: const Text(
                                                          " X ",
                                                          style: TextStyle(
                                                            color: Colors.red,
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              )
                                            : const SizedBox(),
                                        provider.masterCategoryValues.isNotEmpty
                                            ? displaySelectedFilter(
                                                "Gen. Cate :",
                                                "categoryName",
                                                provider.masterCategoryValues,
                                                provider)
                                            : const SizedBox(),
                                        provider.masterProjectCategoryValues
                                                .isNotEmpty
                                            ? displaySelectedFilter(
                                                "Gen.Proj.Cate :",
                                                "projectType",
                                                provider
                                                    .masterProjectCategoryValues,
                                                provider)
                                            : const SizedBox(),
                                        provider.masterCurrentProjectRegionValues
                                                .isNotEmpty
                                            ? displaySelectedFilter(
                                                "Gen.Proj.Region :",
                                                "regionName",
                                                provider
                                                    .masterCurrentProjectRegionValues,
                                                provider)
                                            : const SizedBox(),
                                        provider.masterCurrentProjectProjectValues
                                                .isNotEmpty
                                            ? displaySelectedFilter(
                                                "Gen.Proj.Project :",
                                                "pCategory",
                                                provider
                                                    .masterCurrentProjectProjectValues,
                                                provider)
                                            : const SizedBox(),
                                        provider.masterCurrentProjectProjectLocationValues
                                                .isNotEmpty
                                            ? displaySelectedFilter(
                                                "Gen.Proj.Project Loc. :",
                                                "projectArea",
                                                provider
                                                    .masterCurrentProjectProjectLocationValues,
                                                provider)
                                            : const SizedBox(),
                                        provider.masterDepartmentDepartmentGroupFilterValues
                                                .isNotEmpty
                                            ? displaySelectedFilter(
                                                "Department Dept.G.:",
                                                "groupDeptName",
                                                provider
                                                    .masterDepartmentDepartmentGroupFilterValues,
                                                provider)
                                            : const SizedBox(),
                                        provider.masterDepartmentDepartmentSubGroupFilterValues
                                                .isNotEmpty
                                            ? displaySelectedFilter(
                                                "Department Dept.S.G.:",
                                                "subDeptName",
                                                provider
                                                    .masterDepartmentDepartmentSubGroupFilterValues,
                                                provider)
                                            : const SizedBox(),
                                        provider.masterDepartmentDepartmentFilterValues
                                                .isNotEmpty
                                            ? displaySelectedFilter(
                                                "Department Dept:",
                                                "deptName",
                                                provider
                                                    .masterDepartmentDepartmentFilterValues,
                                                provider)
                                            : const SizedBox(),
                                        provider.masterDepartmentWorkProfileValues
                                                .isNotEmpty
                                            ? displaySelectedFilter(
                                                "Department work profile:",
                                                "workProfile",
                                                provider
                                                    .masterDepartmentWorkProfileValues,
                                                provider)
                                            : const SizedBox(),
                                        provider.masterStatesValues.isNotEmpty
                                            ? displaySelectedFilter(
                                                "General Domicile:",
                                                "stateName",
                                                provider.masterStatesValues,
                                                provider)
                                            : const SizedBox(),
                                        provider.masterEmployeeGroupValues
                                                .isNotEmpty
                                            ? displaySelectedFilter(
                                                "General Emp.Group:",
                                                "grade",
                                                provider
                                                    .masterEmployeeGroupValues,
                                                provider)
                                            : const SizedBox(),
                                        provider.masterGradeValues.isNotEmpty
                                            ? displaySelectedFilter(
                                                "General Grade:",
                                                "levelName",
                                                provider.masterGradeValues,
                                                provider)
                                            : const SizedBox(),
                                        provider.masterGenderSelectedValue != ""
                                            ? Row(
                                                children: [
                                                  Text(
                                                    provider
                                                        .masterGenderSelectedValue,
                                                  ),
                                                  InkWell(
                                                    onTap: () {
                                                      provider.masterGenderSelectedValue =
                                                          "";
                                                      provider
                                                          .clearOpenSearchListData();
                                                      provider
                                                          .applyMasterFilter(
                                                              context, false);
                                                    },
                                                    child: const Text(
                                                      " X ",
                                                      style: TextStyle(
                                                        color: Colors.red,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              )
                                            : SizedBox(),
                                        provider.masterAssociationsCommitteesValues
                                                .isNotEmpty
                                            ? Column(
                                                children: [
                                                  Container(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            right: 10),
                                                    decoration: BoxDecoration(
                                                        color: Color(CommonAppTheme
                                                            .buttonCommonColor),
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                CommonAppTheme
                                                                    .borderRadious)),
                                                    child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(8.0),
                                                        child: Row(
                                                          children: [
                                                            const Text(
                                                              "Associations Committees : ",
                                                              style: TextStyle(
                                                                  color: Colors
                                                                      .white),
                                                            ),
                                                            ...provider
                                                                .masterAssociationsCommitteesValues
                                                                .map(
                                                                  (e) => Text(
                                                                    "${e['text_val']} , ",
                                                                    style:
                                                                        TextStyle(
                                                                      color:
                                                                          Color(
                                                                        CommonAppTheme
                                                                            .whiteColor,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                )
                                                                .toList(),
                                                            InkWell(
                                                              onTap: () {
                                                                provider
                                                                    .masterAssociationsCommitteesValues
                                                                    .clear();
                                                                provider
                                                                    .clearOpenSearchListData();
                                                                provider
                                                                    .applyMasterFilter(
                                                                        context,
                                                                        false);
                                                              },
                                                              child: const Text(
                                                                " X ",
                                                                style:
                                                                    TextStyle(
                                                                  color: Colors
                                                                      .red,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        )),
                                                  ),
                                                ],
                                              )
                                            : const SizedBox(),
                                        provider.masterAssociationsMemberValues
                                                .isNotEmpty
                                            ? Column(
                                                children: [
                                                  Container(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            right: 10),
                                                    decoration: BoxDecoration(
                                                        color: Color(CommonAppTheme
                                                            .buttonCommonColor),
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                CommonAppTheme
                                                                    .borderRadious)),
                                                    child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(8.0),
                                                        child: Row(
                                                          children: [
                                                            const Text(
                                                              "Associations Member : ",
                                                              style: TextStyle(
                                                                  color: Colors
                                                                      .white),
                                                            ),
                                                            ...provider
                                                                .masterAssociationsMemberValues
                                                                .map(
                                                                  (e) => Text(
                                                                    "${e['text_val']} , ",
                                                                    style:
                                                                        TextStyle(
                                                                      color:
                                                                          Color(
                                                                        CommonAppTheme
                                                                            .whiteColor,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                )
                                                                .toList(),
                                                            InkWell(
                                                              onTap: () {
                                                                provider
                                                                    .masterAssociationsMemberValues
                                                                    .clear();
                                                                provider
                                                                    .clearOpenSearchListData();
                                                                provider
                                                                    .applyMasterFilter(
                                                                        context,
                                                                        false);
                                                              },
                                                              child: const Text(
                                                                " X ",
                                                                style:
                                                                    TextStyle(
                                                                  color: Colors
                                                                      .red,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        )),
                                                  ),
                                                ],
                                              )
                                            : const SizedBox(),
                                        provider.masterAssociationsFacultyValues
                                                .isNotEmpty
                                            ? Column(
                                                children: [
                                                  Container(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            right: 10),
                                                    decoration: BoxDecoration(
                                                        color: Color(CommonAppTheme
                                                            .buttonCommonColor),
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                CommonAppTheme
                                                                    .borderRadious)),
                                                    child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(8.0),
                                                        child: Row(
                                                          children: [
                                                            const Text(
                                                              "Associations Faculty : ",
                                                              style: TextStyle(
                                                                  color: Colors
                                                                      .white),
                                                            ),
                                                            ...provider
                                                                .masterAssociationsFacultyValues
                                                                .map(
                                                                  (e) => Text(
                                                                    "${e['text_val']} , ",
                                                                    style:
                                                                        TextStyle(
                                                                      color:
                                                                          Color(
                                                                        CommonAppTheme
                                                                            .whiteColor,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                )
                                                                .toList(),
                                                            InkWell(
                                                              onTap: () {
                                                                provider
                                                                    .masterAssociationsFacultyValues
                                                                    .clear();
                                                                provider
                                                                    .clearOpenSearchListData();
                                                                provider
                                                                    .applyMasterFilter(
                                                                        context,
                                                                        false);
                                                              },
                                                              child: const Text(
                                                                " X ",
                                                                style:
                                                                    TextStyle(
                                                                  color: Colors
                                                                      .red,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        )),
                                                  ),
                                                ],
                                              )
                                            : const SizedBox(),
                                        provider.masterInterestAwardInterestValues
                                                .isNotEmpty
                                            ? Column(
                                                children: [
                                                  Container(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            right: 10),
                                                    decoration: BoxDecoration(
                                                        color: Color(CommonAppTheme
                                                            .buttonCommonColor),
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                CommonAppTheme
                                                                    .borderRadious)),
                                                    child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(8.0),
                                                        child: Row(
                                                          children: [
                                                            const Text(
                                                              "Interest : ",
                                                              style: TextStyle(
                                                                  color: Colors
                                                                      .white),
                                                            ),
                                                            ...provider
                                                                .masterInterestAwardInterestValues
                                                                .map(
                                                                  (e) => Text(
                                                                    "${e['text_val']} , ",
                                                                    style:
                                                                        TextStyle(
                                                                      color:
                                                                          Color(
                                                                        CommonAppTheme
                                                                            .whiteColor,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                )
                                                                .toList(),
                                                            InkWell(
                                                              onTap: () {
                                                                provider
                                                                    .masterInterestAwardInterestValues
                                                                    .clear();
                                                                provider
                                                                    .clearOpenSearchListData();
                                                                provider
                                                                    .applyMasterFilter(
                                                                        context,
                                                                        false);
                                                              },
                                                              child: const Text(
                                                                " X ",
                                                                style:
                                                                    TextStyle(
                                                                  color: Colors
                                                                      .red,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        )),
                                                  ),
                                                ],
                                              )
                                            : const SizedBox(),
                                        provider.masterInterestAwardAchievementValues
                                                .isNotEmpty
                                            ? Column(
                                                children: [
                                                  Container(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            right: 10),
                                                    decoration: BoxDecoration(
                                                        color: Color(CommonAppTheme
                                                            .buttonCommonColor),
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                CommonAppTheme
                                                                    .borderRadious)),
                                                    child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(8.0),
                                                        child: Row(
                                                          children: [
                                                            const Text(
                                                              "Achievements: ",
                                                              style: TextStyle(
                                                                  color: Colors
                                                                      .white),
                                                            ),
                                                            ...provider
                                                                .masterInterestAwardAchievementValues
                                                                .map(
                                                                  (e) => Text(
                                                                    "${e['text_val']} , ",
                                                                    style:
                                                                        TextStyle(
                                                                      color:
                                                                          Color(
                                                                        CommonAppTheme
                                                                            .whiteColor,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                )
                                                                .toList(),
                                                            InkWell(
                                                              onTap: () {
                                                                provider
                                                                    .masterInterestAwardAchievementValues
                                                                    .clear();
                                                                provider
                                                                    .clearOpenSearchListData();
                                                                provider
                                                                    .applyMasterFilter(
                                                                        context,
                                                                        false);
                                                              },
                                                              child: const Text(
                                                                " X ",
                                                                style:
                                                                    TextStyle(
                                                                  color: Colors
                                                                      .red,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        )),
                                                  ),
                                                ],
                                              )
                                            : const SizedBox(),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: CommonAppTheme.lineheightSpace20,
                              ),
                            ],
                          )
                        : const SizedBox(),
                  ),
                  Consumer<AllInProvider>(
                    builder: (context, value, child) => provider
                            .openSearchEmpDataDummy.isEmpty
                        ? const SizedBox()
                        : ListView.builder(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: provider.openSearchEmpDataDummy.length,
                            itemBuilder: (context, index) => Padding(
                              padding: const EdgeInsets.only(bottom: 10),
                              child: Card(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                margin: EdgeInsets.zero,
                                elevation: 5,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    ExpansionTile(
                                      title: ListTile(
                                        contentPadding: const EdgeInsets.only(
                                            left: 0.0, right: 0.0),
                                        leading: InkWell(
                                          onTap: () {
                                            provider.viewProfile(
                                                context,
                                                provider.openSearchEmpDataDummy[
                                                    index]['empNo']);
                                          },
                                          child: CircleAvatar(
                                            radius: 30,
                                            backgroundImage: NetworkImage(
                                                "https://delphi.ntpc.co.in/${provider.openSearchEmpDataDummy[index]['imgPath']}"),
                                          ),
                                        ),
                                        title: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              "${provider.openSearchEmpDataDummy[index]['name']}(${provider.openSearchEmpDataDummy[index]['pernr']})",
                                              style: TextStyle(
                                                fontSize: 12,
                                                color: Color(CommonAppTheme
                                                    .buttonCommonColor),
                                              ),
                                            ),
                                            const SizedBox(
                                              height: 5,
                                            ),
                                            Text(
                                              "${provider.openSearchEmpDataDummy[index]['grade']} ${provider.openSearchEmpDataDummy[index]['designation']}",
                                              style: const TextStyle(
                                                  fontSize: 12,
                                                  color: Colors.black),
                                            ),
                                            const SizedBox(
                                              height: 5,
                                            ),
                                          ],
                                        ),
                                        subtitle: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              " ${provider.openSearchEmpDataDummy[index]['department']}",
                                              style: const TextStyle(
                                                  fontSize: 12,
                                                  color: Colors.black),
                                            ),
                                            const SizedBox(
                                              height: 5,
                                            ),
                                            Text(
                                              "${provider.openSearchEmpDataDummy[index]['project'].toLowerCase() == provider.openSearchEmpDataDummy[index]['location'].toLowerCase() ? provider.openSearchEmpDataDummy[index]['project'] : '${provider.openSearchEmpDataDummy[index]['project']} ${provider.openSearchEmpDataDummy[index]['location']}'}",
                                              style: const TextStyle(
                                                  fontSize: 12,
                                                  color: Colors.black),
                                            ),
                                            const SizedBox(
                                              height: 10,
                                            ),
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.end,
                                              children: [
                                                provider.openSearchEmpDataDummy[
                                                                index]
                                                            ['keyPosition'] ==
                                                        ""
                                                    ? const SizedBox()
                                                    : Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(right: 5),
                                                        child: Image.asset(
                                                          "assets/images/key.png",
                                                          width: 30,
                                                        ),
                                                      ),
                                                provider.openSearchEmpDataDummy[
                                                                index]
                                                            ['alertMsg'] ==
                                                        ""
                                                    ? const SizedBox()
                                                    : Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(right: 5),
                                                        child: Image.asset(
                                                          "assets/images/men.png",
                                                          width: 30,
                                                        ),
                                                      ),
                                                Image.asset(
                                                  "assets/images/group1.png",
                                                  width: 30,
                                                ),
                                                Expanded(
                                                  child: Align(
                                                    alignment:
                                                        Alignment.centerRight,
                                                    child: Switch(
                                                      materialTapTargetSize:
                                                          MaterialTapTargetSize
                                                              .shrinkWrap,
                                                      value: provider.openSearchEmpDataDummy[
                                                                      index][
                                                                  'isEligibleEmp'] ==
                                                              "False"
                                                          ? false
                                                          : true,
                                                      onChanged: (value) {
                                                        print(provider
                                                                .openSearchEmpDataDummy[
                                                            index]['empNo']);
                                                        if (value) {
                                                          if (compareList
                                                                  .length >=
                                                              3) {
                                                            CommanDialog
                                                                .showErrorDialog(
                                                                    context,
                                                                    description:
                                                                        "You can not compare more than 3 employees.");
                                                          } else {
                                                            setState(() {
                                                              provider.openSearchEmpDataDummy[
                                                                          index]
                                                                      [
                                                                      'isEligibleEmp'] =
                                                                  "true";
                                                            });
                                                            if (compareList.contains(
                                                                provider.openSearchEmpDataDummy[
                                                                        index][
                                                                    'empNo'])) {
                                                              compareList.removeWhere((element) =>
                                                                  element ==
                                                                  provider.openSearchEmpDataDummy[
                                                                          index]
                                                                      [
                                                                      'empNo']);
                                                            } else {
                                                              compareList.add(
                                                                  provider.openSearchEmpDataDummy[
                                                                          index]
                                                                      [
                                                                      'empNo']);
                                                            }
                                                          }
                                                        } else {
                                                          setState(() {
                                                            provider.openSearchEmpDataDummy[
                                                                        index][
                                                                    'isEligibleEmp'] =
                                                                "False";
                                                            if (compareList.contains(
                                                                provider.openSearchEmpDataDummy[
                                                                        index][
                                                                    'empNo'])) {
                                                              compareList.removeWhere((element) =>
                                                                  element ==
                                                                  provider.openSearchEmpDataDummy[
                                                                          index]
                                                                      [
                                                                      'empNo']);
                                                            } else {
                                                              compareList.add(
                                                                  provider.openSearchEmpDataDummy[
                                                                          index]
                                                                      [
                                                                      'empNo']);
                                                            }
                                                          });
                                                        }
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                      children: [
                                        Container(
                                          color: const Color(0xFFE3EEF6),
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Column(
                                              children: [
                                                employeeDetail('Hiring Mode:',
                                                    " ${provider.openSearchEmpDataDummy[index]['entrymode']}"),
                                                employeeDetail(
                                                    'Domicile State:',
                                                    " ${provider.openSearchEmpDataDummy[index]['domicile_State']}"),
                                                employeeDetail(
                                                    "D.O.E. Project:",
                                                    " ${provider.openSearchEmpDataDummy[index]['doE_Project']}"),
                                                employeeDetail("D.O.E. Grade:",
                                                    " ${provider.openSearchEmpDataDummy[index]['doE_Grade']}"),
                                                employeeDetail("D.O.B.:",
                                                    " ${provider.openSearchEmpDataDummy[index]['dob']} (${provider.openSearchEmpDataDummy[index]['age']})"),
                                                employeeDetail("Prev. Proj.:",
                                                    " ${provider.openSearchEmpDataDummy[index]['prev_Proj']}"),
                                                employeeDetail(
                                                  "Spouse in NTPC:",
                                                  provider.openSearchEmpDataDummy[
                                                                  index]
                                                              ['spouseID'] ==
                                                          ""
                                                      ? " NO"
                                                      : " Yes",
                                                ),
                                                employeeDetail("Total Exp:",
                                                    " ${provider.openSearchEmpDataDummy[index]['totalExp']}"),
                                                Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Text(
                                                      "Loc.Exp:   ",
                                                      style: TextStyle(
                                                        color: Color(
                                                          CommonAppTheme
                                                              .appthemeColorForText,
                                                        ),
                                                        fontWeight:
                                                            FontWeight.bold,
                                                      ),
                                                    ),
                                                    Flexible(
                                                      child: Text(
                                                        "${provider.openSearchEmpDataDummy[index]['locationExp']}",
                                                        textAlign:
                                                            TextAlign.left,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                const SizedBox(
                                                  height: 10,
                                                ),
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Text("Dept.Exp :",
                                                        style: TextStyle(
                                                          color: Color(
                                                            CommonAppTheme
                                                                .appthemeColorForText,
                                                          ),
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        )),
                                                    Flexible(
                                                      child: Text(
                                                        "${provider.openSearchEmpDataDummy[index]['functionExp']}",
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          if (compareList.length >= 2) {
            String cmp = ",${compareList.join(',')},";
            provider.getEmpCompareSearchData(context, {'EmployeeIdList': cmp});
          }
        },
        label: Row(
          children: [
            Image.asset(
              "assets/images/compare.png",
              width: 25,
              color: Color(CommonAppTheme.whiteColor),
            ),
            Text(
              "Compare",
              style: TextStyle(
                color: Color(
                  CommonAppTheme.whiteColor,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
