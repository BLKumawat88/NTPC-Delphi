import 'package:flutter/material.dart';

class SpalshScreenMain extends StatelessWidget {
  const SpalshScreenMain({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Image.asset("assets/images/splashNTPC.png"),
      ),
    );
  }
}
