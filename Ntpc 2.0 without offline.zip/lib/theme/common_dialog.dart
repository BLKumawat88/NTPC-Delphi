import 'package:flutter/material.dart';

class CommanDialog {
  static showLoading(context, {String title = 'Loading...'}) {
    showDialog(
      context: context,
      builder: (context) {
        return const Center(
          child: CircularProgressIndicator.adaptive(
            backgroundColor: Colors.black,
          ),
        );
      },
    );
  }

  static refereshScreen(context, {String title = 'Loading...'}) {
    showDialog(
      context: context,
      builder: (context) {
        return const Center(
          child:
              CircularProgressIndicator.adaptive(backgroundColor: Colors.black),
        );
      },
    );
  }

  static hideLoading(context) {
    Navigator.pop(context);
  }

  static showErrorDialog(
    context, {
    String title = "Oops Error",
    String description = "Something went wrong ",
  }) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          content: Container(
            height: 100,
            child: Column(children: [
              Text(description),
              SizedBox(
                height: 10,
              ),
              ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text("OK"))
            ]),
          ),
        );
      },
    );
  }
}
