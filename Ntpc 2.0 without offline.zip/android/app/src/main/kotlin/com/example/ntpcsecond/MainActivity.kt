package com.example.ntpcsecond

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
